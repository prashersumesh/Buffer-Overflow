#!/bin/bash
# Sumesh Kumar
./product_register abc $(python -c 'print "A"*32 + "\x01"')
