/* global React */
const { useState, useEffect, useRef, useMemo } = React;

/* ============================================================
   StackDiagram — animated buffer overflow visualizer
   ============================================================ */
function StackDiagram({ layout, payload, speed = 1, autoPlay = true, label = "stack memory" }) {
  // layout: [{ name, bytes, addr, role }]  role: buffer | target | other | retaddr | arg
  // payload: [{ value, role, count }]
  const totalBytes = layout.reduce((s, r) => s + r.bytes, 0);
  const flatPayload = useMemo(() => {
    const out = [];
    payload.forEach(p => {
      for (let i = 0; i < p.count; i++) {
        out.push({ value: p.value, role: p.role, glyph: p.glyph });
      }
    });
    return out;
  }, [payload]);

  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(autoPlay);

  useEffect(() => {
    if (!playing) return;
    if (step >= flatPayload.length) return;
    const t = setTimeout(() => setStep(step + 1), Math.max(20, 120 / speed));
    return () => clearTimeout(t);
  }, [step, playing, flatPayload.length, speed]);

  // Map each byte index in the flat stack to its (rowIdx, byteIdxInRow)
  const byteMap = useMemo(() => {
    const m = [];
    layout.forEach((row, ri) => {
      for (let i = 0; i < row.bytes; i++) m.push({ ri, i });
    });
    return m;
  }, [layout]);

  const cellState = (globalIdx, row, byteIdxInRow) => {
    if (globalIdx >= step) {
      // not yet filled
      return { cls: '', glyph: '·' };
    }
    const p = flatPayload[globalIdx];
    if (!p) return { cls: 'filled', glyph: '·' };
    const overflowing = globalIdx >= layout[0].bytes;
    return {
      cls: overflowing && p.role !== 'pad' ? p.role : 'payload',
      glyph: p.glyph || (p.value || '?'),
    };
  };

  // Row is corrupted if any byte beyond its buffer's intent was overwritten
  const rowCorrupted = (rowIdx) => {
    const row = layout[rowIdx];
    if (row.role === 'buffer') return false; // buffer is supposed to be filled
    let start = 0;
    for (let i = 0; i < rowIdx; i++) start += layout[i].bytes;
    const end = start + row.bytes;
    return step > start && row.role !== 'pad';
  };

  const reset = () => { setStep(0); setPlaying(true); };
  const stepFwd = () => { setPlaying(false); setStep(Math.min(step + 1, flatPayload.length)); };
  const playPause = () => setPlaying(!playing);
  const done = () => { setPlaying(false); setStep(flatPayload.length); };

  let runningIdx = 0;

  return (
    <div className="panel">
      <div className="panel-head">
        <div className="title mono"><span className="tag">› </span>{label}</div>
        <div className="actions">
          <button onClick={reset}>↺ reset</button>
          <button onClick={stepFwd}>+1 byte</button>
          <button onClick={done}>finish</button>
          <button className={playing ? 'primary' : ''} onClick={playPause}>
            {playing ? '❚❚ pause' : '▶ play'}
          </button>
        </div>
      </div>
      <div className="stack-vis">
        <div className="addr-col">
          {layout.map((row, ri) => (
            <div key={ri} className="addr">{row.addr}</div>
          ))}
        </div>
        <div className="stack-frame">
          {layout.map((row, ri) => {
            const corrupted = rowCorrupted(ri);
            const targetMatch = row.role === 'target' && step > totalBytes - row.bytes;
            return (
              <div
                key={ri}
                className={`stack-row ${corrupted ? 'corrupted' : ''} ${row.role === 'target' && corrupted ? 'target' : ''}`}
              >
                <div className="row-label">
                  <span className="name">{row.name}</span>
                  <span className="meta">{row.bytes}B · {row.note || row.role}</span>
                </div>
                <div className="bytes">
                  {Array.from({ length: row.bytes }).map((_, bi) => {
                    const gi = runningIdx++;
                    const { cls, glyph } = cellState(gi, row, bi);
                    return (
                      <div key={bi} className={`byte ${cls}`} title={`offset ${gi}`}>
                        {glyph}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
        <div className="legend">
          <div className="item"><span className="sw" style={{background:'var(--byte-A)'}}></span>uninit</div>
          <div className="item"><span className="sw" style={{background:'var(--byte-payload)'}}></span>padding (A)</div>
          <div className="item"><span className="sw" style={{background:'var(--byte-corrupt)'}}></span>corruption</div>
          <div className="item"><span className="sw" style={{background:'var(--byte-target)'}}></span>system() addr</div>
          <div className="item"><span className="sw" style={{background:'var(--byte-ret)'}}></span>fake return</div>
          <div className="item"><span className="sw" style={{background:'var(--byte-shell)'}}></span>/bin/sh ptr</div>
          <div className="item" style={{marginTop:8, color:'var(--text)'}}>
            <b>{step}</b><span className="muted">/{flatPayload.length}</span> bytes written
          </div>
        </div>
      </div>
    </div>
  );
}

window.StackDiagram = StackDiagram;
