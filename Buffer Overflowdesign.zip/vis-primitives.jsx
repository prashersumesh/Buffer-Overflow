/* global React */
/* ============================================================
   Small visual primitives
   ============================================================ */

function PayloadStrip({ blocks }) {
  // blocks: [{ name, hex, bytes, color, note }]
  return (
    <div className="payload-strip">
      {blocks.map((b, i) => (
        <div key={i} className="payload-block" style={{ flex: b.bytes }}>
          <div className="swatch" style={{ background: b.color }}>{b.bytes}B</div>
          <div className="info">
            <span className="name">{b.name}</span>
            <div className="hex">{b.hex}</div>
            {b.note && <div className="muted" style={{marginTop:4, fontSize:10}}>{b.note}</div>}
          </div>
        </div>
      ))}
    </div>
  );
}

function CodePanel({ title, tag = 'C', lines }) {
  // lines: [{ n, html, hl }]
  return (
    <div className="panel">
      <div className="panel-head">
        <div className="title mono"><span className="tag">{tag} · </span>{title}</div>
        <div className="actions"><button>copy</button></div>
      </div>
      <div className="panel-body">
        <pre className="code">
          {lines.map((l, i) => (
            <div key={i} className={l.hl ? 'hl' : ''} style={l.hl ? null : null}>
              <span className="ln">{l.n}</span>
              <span dangerouslySetInnerHTML={{ __html: l.html }} />
            </div>
          ))}
        </pre>
      </div>
    </div>
  );
}

function Chip({ label, value }) {
  return (
    <div className="chip">
      <span className="lbl">{label}</span>
      <b>{value}</b>
    </div>
  );
}

function KV({ rows }) {
  return (
    <div className="kv">
      {rows.map((r, i) => (
        <React.Fragment key={i}>
          <div className="k">{r.k}</div>
          <div className="v" dangerouslySetInnerHTML={{ __html: r.v }} />
        </React.Fragment>
      ))}
    </div>
  );
}

window.PayloadStrip = PayloadStrip;
window.CodePanel = CodePanel;
window.Chip = Chip;
window.KV = KV;
