/* global React */
const { useState: useStateT, useEffect: useEffectT, useRef: useRefT } = React;

/* ============================================================
   Terminal — typewriter terminal that plays a script
   script: [{kind, text, delay?}]   kinds: cmd, out, accept, err, rootCmd, blank
   ============================================================ */
function Terminal({ script, speed = 1, title = "uogsec@ubuntu: ~/buffer_overflow", autoPlay = true }) {
  const [lines, setLines] = useStateT([]);    // rendered lines
  const [cur, setCur] = useStateT('');         // current typing line
  const [idx, setIdx] = useStateT(0);          // script index
  const [chIdx, setChIdx] = useStateT(0);      // char position within current
  const [playing, setPlaying] = useStateT(autoPlay);
  const bodyRef = useRefT(null);

  useEffectT(() => { setLines([]); setCur(''); setIdx(0); setChIdx(0); setPlaying(autoPlay); }, [script]);

  useEffectT(() => {
    if (!playing) return;
    if (idx >= script.length) return;
    const item = script[idx];

    if (item.kind === 'blank') {
      const t = setTimeout(() => {
        setLines(l => [...l, { kind: 'blank', text: '' }]);
        setIdx(i => i + 1);
      }, 80 / speed);
      return () => clearTimeout(t);
    }

    // Output lines render instantly (line-by-line), with a small delay
    if (item.kind === 'out' || item.kind === 'accept' || item.kind === 'err') {
      const t = setTimeout(() => {
        setLines(l => [...l, item]);
        setIdx(i => i + 1);
      }, (item.delay || 180) / speed);
      return () => clearTimeout(t);
    }

    // cmd / rootCmd: type char by char
    if (chIdx < item.text.length) {
      const t = setTimeout(() => {
        setCur(item.text.slice(0, chIdx + 1));
        setChIdx(chIdx + 1);
      }, (item.fast ? 14 : 30) / speed);
      return () => clearTimeout(t);
    } else {
      const t = setTimeout(() => {
        setLines(l => [...l, item]);
        setCur('');
        setChIdx(0);
        setIdx(i => i + 1);
      }, (item.delay || 350) / speed);
      return () => clearTimeout(t);
    }
  }, [playing, idx, chIdx, script, speed]);

  useEffectT(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [lines, cur]);

  const reset = () => { setLines([]); setCur(''); setIdx(0); setChIdx(0); setPlaying(true); };

  const renderPrompt = (kind) => {
    if (kind === 'rootCmd') return <span className="root-prompt">root@ubuntu</span>;
    return <span className="prompt">uogsec@ubuntu</span>;
  };
  const renderTail = (kind) => {
    if (kind === 'rootCmd') return <span>:<span className="path">~/buffer_overflow</span>{' # '}</span>;
    return <span>:<span className="path">~/buffer_overflow</span>{' $ '}</span>;
  };

  const renderLine = (item, key) => {
    if (item.kind === 'blank') return <div key={key}>{' '}</div>;
    if (item.kind === 'out')    return <div key={key} className="out">{item.text}</div>;
    if (item.kind === 'accept') return <div key={key} className="accept">{item.text}</div>;
    if (item.kind === 'err')    return <div key={key} className="err">{item.text}</div>;
    return (
      <div key={key}>
        {renderPrompt(item.kind)}{renderTail(item.kind)}<span>{item.text}</span>
      </div>
    );
  };

  const currentItem = script[idx];

  return (
    <div className="terminal">
      <div className="terminal-head">
        <div className="dots"><span className="dot" style={{background:'#ff5f57'}}></span><span className="dot" style={{background:'#febc2e'}}></span><span className="dot" style={{background:'#28c840'}}></span></div>
        <div className="title">{title}</div>
        <div style={{marginLeft:'auto', display:'flex', gap:8}}>
          <button onClick={reset} style={{
            background:'transparent', color:'#8a93a3', border:'1px solid #2b3543',
            fontSize:10, padding:'2px 8px', borderRadius:3, cursor:'pointer',
            fontFamily:'var(--mono)', letterSpacing:'0.06em', textTransform:'uppercase'
          }}>replay</button>
        </div>
      </div>
      <div className="terminal-body" ref={bodyRef}>
        {lines.map((l, i) => renderLine(l, i))}
        {currentItem && (currentItem.kind === 'cmd' || currentItem.kind === 'rootCmd') && (
          <div>
            {renderPrompt(currentItem.kind)}{renderTail(currentItem.kind)}
            <span>{cur}</span>
            <span className="cursor"></span>
          </div>
        )}
        {!currentItem && <span className="cursor"></span>}
      </div>
    </div>
  );
}

window.Terminal = Terminal;
